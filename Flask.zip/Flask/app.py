from flask import Flask, render_template, request, redirect, url_for, flash
import gspread
from google.oauth2.service_account import Credentials
import pandas as pd
import os
from pyngrok import ngrok, conf, exception
from werkzeug.utils import secure_filename

# ====== Flask App Setup ======
app = Flask(__name__)
app.secret_key = "secret-key-123"  # dùng cho flash messages

# ====== Google Sheet Setup ======
scopes = ['https://www.googleapis.com/auth/spreadsheets']
creds = Credentials.from_service_account_file('credentials.json', scopes=scopes)
client = gspread.authorize(creds)

SHEET_ID = '1sOER16FawaPCyzzZQCbATOlLgDBxSThgRHnANjwlpd0'
sheet_doctors = client.open_by_key(SHEET_ID).worksheet('doctors')

UPLOAD_FOLDER = "static/uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)


# ====== ROUTE: Trang chủ (Form nhập & Upload) ======
@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')


# ====== ROUTE: Xử lý form thêm bác sĩ ======
@app.route('/doctor', methods=['POST'])
def add_doctor():
    try:
        name = request.form.get('name')
        age = request.form.get('age')
        department = request.form.get('department')
        hospital = request.form.get('hospital')
        note = request.form.get('note', '')
        image = request.files.get('image')

        if not all([name, age, department, hospital]):
            flash('⚠️ Vui lòng điền đủ thông tin bắt buộc.')
            return redirect(url_for('index'))

        image_path = ''
        if image and image.filename != '':
            filename = secure_filename(image.filename)
            save_path = os.path.join(UPLOAD_FOLDER, filename)
            image.save(save_path)
            image_path = f"/{save_path}"

        sheet_doctors.append_row([name, age, department, hospital, note, image_path])
        flash('✅ Đã ghi nhận thông tin bác sĩ thành công!')
    except Exception as e:
        flash(f'❌ Lỗi khi thêm bác sĩ: {e}')

    return redirect(url_for('index'))



# ====== ROUTE: Upload file CSV / Excel ======
@app.route('/upload', methods=['POST'])
def upload_file():
    file = request.files.get('file')

    if not file:
        flash('⚠️ Vui lòng chọn file trước khi tải lên.')
        return redirect(url_for('index'))

    filename = file.filename
    ext = os.path.splitext(filename)[1].lower()

    try:
        if ext == '.csv':
            df = pd.read_csv(file)
        elif ext in ['.xlsx', '.xls']:
            df = pd.read_excel(file)
        else:
            flash('❌ Định dạng file không được hỗ trợ.')
            return redirect(url_for('index'))

        # Chuẩn hóa cột (đưa về chữ thường, bỏ khoảng trắng)
        df.columns = [col.strip().lower() for col in df.columns]

        # Đảm bảo có đủ cột cần thiết
        for col in ['name', 'age', 'department', 'hospital', 'note', 'image_url']:
            if col not in df.columns:
                df[col] = ""

        success, failed = 0, 0

        for _, row in df.iterrows():
            try:
                # 🧩 Kiểm tra & làm sạch link ảnh
                image_url = str(row.get('image_url', '')).strip()
                if not image_url.startswith(('http://', 'https://')):
                    image_url = ""  # bỏ qua nếu không phải link hợp lệ

                data = [
                    row.get('name'),
                    row.get('age'),
                    row.get('department'),
                    row.get('hospital'),
                    row.get('note', ''),
                    image_url
                ]

                # ⚠️ Bỏ qua dòng thiếu thông tin bắt buộc
                if not all([data[0], data[1], data[2], data[3]]):
                    failed += 1
                    continue

                # Thêm vào Google Sheet
                sheet_doctors.append_row([str(x) if pd.notna(x) else "" for x in data])
                success += 1
            except Exception as e:
                print(f"Lỗi ở dòng: {e}")  # để debug
                failed += 1

        # Thông báo kết quả
        msg = f"✅ Đã nhập {success} dòng thành công."
        if failed > 0:
            msg += f" ⚠️ Bỏ qua {failed} dòng lỗi."
        flash(msg)

    except Exception as e:
        flash(f'❌ Lỗi khi đọc file: {e}')

    return redirect(url_for('index'))

# ====== ROUTE: Xem dữ liệu ======
@app.route('/view', methods=['GET'])
def view_data():
    try:
        records = sheet_doctors.get_all_records()
        total_doctors = len(records)
        departments = len(set(d['department'] for d in records if d.get('department')))
        hospitals = len(set(d['hospital'] for d in records if d.get('hospital')))
    except Exception as e:
        records, total_doctors, departments, hospitals = [], 0, 0, 0
        flash(f'Lỗi khi lấy dữ liệu: {e}')
    return render_template('view.html',
                           doctors=records,
                           total_doctors=total_doctors,
                           departments=departments,
                           hospitals=hospitals)

# ====== ROUTE: Xóa dữ liệu bác sĩ ======
@app.route('/delete/<int:row>', methods=['POST'])
def delete_doctor(row):
    try:
        # ⚠️ +1 vì Google Sheet có header ở hàng đầu tiên
        sheet_doctors.delete_rows(row + 1)
        flash('🗑️ Đã xóa bác sĩ thành công!')
    except Exception as e:
        flash(f'❌ Lỗi khi xóa bác sĩ: {e}')
    return redirect(url_for('view_data'))


# ====== ROUTE: Cập nhật dữ liệu bác sĩ ======
@app.route('/update', methods=['POST'])
def update_doctor():
    row = int(request.form.get('row'))
    data = [
        request.form.get('name'),
        request.form.get('age'),
        request.form.get('department'),
        request.form.get('hospital'),
    ]
    try:
        # ⚠️ +1 vì dòng đầu là header
        sheet_doctors.update(f"A{row+1}:D{row+1}", [data])
        flash('✅ Đã cập nhật thông tin bác sĩ thành công!')
    except Exception as e:
        flash(f'❌ Lỗi khi cập nhật: {e}')
    return redirect(url_for('view_data'))



# ====== AUTO NGROK STARTUP ======
def start_ngrok():
    """Tự động khởi động ngrok và xử lý lỗi tunnel trùng (hỗ trợ cả Windows)"""
    try:
        public_url = ngrok.connect(5000)
        print(f"🌐 Public URL: {public_url}")
    except exception.PyngrokNgrokHTTPError as e:
        if "ERR_NGROK_334" in str(e):
            print("⚠️ Tunnel cũ vẫn đang chạy — đang khởi động lại...")
            # Kill tiến trình ngrok.exe (Windows)
            os.system("taskkill /f /im ngrok.exe >nul 2>&1")
            public_url = ngrok.connect(5000)
            print(f"🌐 Public URL (đã reset): {public_url}")
        else:
            raise e


if __name__ == '__main__':
    app.config['SEND_FILE_MAX_AGE_DEFAULT'] = 0  # tắt cache static
    start_ngrok()  # auto mở ngrok tunnel
    app.run(debug=True)
